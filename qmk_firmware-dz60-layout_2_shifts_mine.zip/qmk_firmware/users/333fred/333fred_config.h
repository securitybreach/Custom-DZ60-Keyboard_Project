#pragma once

#define PREVENT_STUCK_MODIFIERS
#define PERMISSIVE_HOLD
