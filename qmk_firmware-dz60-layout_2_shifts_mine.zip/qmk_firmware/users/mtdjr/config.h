#ifndef USERSPACE_CONFIG_H
#define USERSPACE_CONFIG_H

// Put normal config.h settings here:
#define TAPPING_TERM 250

#endif // !USERSPACE_CONFIG_H
