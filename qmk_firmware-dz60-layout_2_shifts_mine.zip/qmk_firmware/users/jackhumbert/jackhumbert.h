#ifndef USERSPACE
#define USERSPACE

#include "quantum.h"

#endif