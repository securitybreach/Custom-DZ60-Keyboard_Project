//define diablo macro timer variables
extern uint16_t diablo_timer[4];
extern uint8_t diablo_times[];
extern uint8_t diablo_key_time[4];


void run_diablo_macro_check(void);
