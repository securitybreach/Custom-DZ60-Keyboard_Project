#ifndef NQN_COMMON_H
#define NQN_COMMON_H


/*
This file holds some commen NQN definitions
*/


#define _______ KC_TRNS
#define XXXXXXX KC_NO


#endif
