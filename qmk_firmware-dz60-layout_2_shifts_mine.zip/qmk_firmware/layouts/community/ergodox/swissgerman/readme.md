# ErgoDox Swiss German Configuration

Swiss German keyboard layout based on the Ergodox EZ default layout.

Keyboard diagrams created with the [keyboard layout editor](http://www.keyboard-layout-editor.com).

Diagram sources: [default layer](keyboard-layout.json), [layer 1 & 2](keyboard-layout_1_2.json)

![Layout Layer 0](https://i.imgur.com/yf4HNXV.png)
![Layout Layer 1&2](https://i.imgur.com/Q814cKa.png)

## Changelog
* Jan 21, 2017:
  * Initial version based on default layout.

