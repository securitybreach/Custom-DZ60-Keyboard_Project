#pragma once

#include QMK_KEYBOARD_CONFIG_H
#include "333fred_config.h"

#undef TAPPING_TERM
#define TAPPING_TERM 200
