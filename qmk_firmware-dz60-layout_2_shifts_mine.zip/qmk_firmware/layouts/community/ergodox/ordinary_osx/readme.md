# The Ordinary Layout for OSX #

It is based on [Ordinary Layout](../ordinary/readme.md) with some keys re-mapped for OSX.
