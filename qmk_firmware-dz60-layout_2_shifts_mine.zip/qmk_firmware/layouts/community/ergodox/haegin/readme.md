# Haegin's Ergodox Firmware

Mostly uses keys available on the Minidox, with some extras that are nice
to have when they're available, provided they're in a roughly similar place on
the Model 01.
