## v0.3

*2016-10-11*

### Starting point

* The starting point of this keymap. A beginner layout, and a couple placeholders.
