# Robot test layout

Use this layout if you like to pretend you're [Norman](https://www.youtube.com/watch?v=-sbxFBay-tg), the ErgoDox EZ manufacturing robot.

It's really meant just for internal use, but we're posting it on GitHub anyway, because hurray to open source. :)
