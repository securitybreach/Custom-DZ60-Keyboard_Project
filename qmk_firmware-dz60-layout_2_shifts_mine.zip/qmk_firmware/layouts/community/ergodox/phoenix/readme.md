# ErgoDox EZ Phoenix Configuration

I started working using the default layout.  The changes that I made are largely things that I consistely do wrong.

As a programmer I hit tab a lot for autocomplete so that muscle memory is very difficult to re-write.  The stragest change might be all the keys that I cleared in the Code layer.  This is mainly to facilitate quickly typing uuids, as sometimes it is quite tedious to copy/paste them from one window to the other.

## Changelog

* April 25, 2016 (V1.0): 
  * Initial submission.
