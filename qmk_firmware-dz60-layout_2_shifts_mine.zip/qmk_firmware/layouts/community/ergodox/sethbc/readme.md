# sethbc's Ergodox EZ keymap

Largely based on the Ergodox Infinity default keymap, but layer locking has been
removed in favor of momentary layer activation
