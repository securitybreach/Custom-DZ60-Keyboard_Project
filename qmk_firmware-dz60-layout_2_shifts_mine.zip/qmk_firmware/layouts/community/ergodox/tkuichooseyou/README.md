# Based on Default OSX
I'm a vim and OSX user

- Moved Hyper and Meh up, replaced with CMD
  - Because I'm used to having symmetrical CMD keys on both hands
- Changed left delete to Tab to match OSX
- Changed left Backspace to CTRL/ESC for vim
- Changed top left and top right arrow to `CMD+{` and `CMD+}`
  - Useful for switching tabs in Safari, Xcode, etc.
- Remove the Ctrl from Z and /
- Remove CMD from right quote
- Changed right Alt to Delete

