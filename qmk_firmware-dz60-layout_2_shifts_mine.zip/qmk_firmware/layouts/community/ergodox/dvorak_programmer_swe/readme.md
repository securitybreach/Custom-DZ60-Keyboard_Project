# ErgoDox EZ Dvorak Programmer SWEDISH

Dvorak layout adjusted for a suitable programmer layout and swedish special characters added:

* åäö characters added
* Layout for common vb.net keywords
* Common Visual Studio commands like Save, Build, Debug

TODO:

* (Layer 4 is qwerty (for easier gaming & less fortunate keyboard users)) Like this idea, will add it later on

Known issues:

* Keymap 2 modifier has not gotten its place yet..
* Print screen, where?


## Changelog

* 2017-05-16
  * Initial release

# Author
Christian Westerlund
cwesterlund @ github

Thanks to the author of keymap csharp_dev for inspiration!