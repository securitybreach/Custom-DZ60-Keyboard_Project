#ifndef CONFIG_USER_H
#define CONFIG_USER_H

#include QMK_KEYBOARD_CONFIG_H

#ifndef NO_DEBUG
  #define NO_DEBUG
#endif
#ifndef NO_PRINT
  #define NO_PRINT
#endif

#endif
