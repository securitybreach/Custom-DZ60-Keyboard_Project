# fullsize_ansi

    LAYOUT_fullsize_ansi