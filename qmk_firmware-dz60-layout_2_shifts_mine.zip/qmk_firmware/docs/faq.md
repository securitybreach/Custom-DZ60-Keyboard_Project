# Frequently Asked Questions

* [General](faq_general.md)
* [Building or Compiling QMK](faq_build.md)
* [Debugging and Troubleshooting QMK](faq_debug.md)
* [Keymap](faq_keymap.md)
